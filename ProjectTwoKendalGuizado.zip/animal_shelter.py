from pymongo import MongoClient
from bson.objectid import ObjectId
from pymongo.errors import PyMongoError 

class AnimalShelter(object):
    def __init__(self, username, password):
        self.USER = 'aacuser'
        self.PASS = 'Oakmont'
        self.HOST = 'nv-desktop-services.apporto.com'
        self.PORT = 30362
        self.DB = 'AAC'
        self.COL = 'animals'
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (self.USER,self.PASS,self.HOST,self.PORT))
        self.database = self.client['%s' % (self.DB)]
        self.collection = self.database[ '%s' % (self.COL)]
    def create(self, data):
        if data is not None:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        else:
            raise Exception("Nothing to save because the data parameter is empty")
            return false
    def read(self, query):
        try:
            result = self.collection.find(query)
            return list(result) if result else []
        except PyMongoError as e:
            print(f"Error reading document(s): {e}")
            return None
                        
    def update(self, query, data):
        try:
            result = self.collection.update_many(query, {'$set': data})
            return (f"Documents Updated: {result.modified_count}")
        except PyMongoError as e:
            print(f"Error updating document(s): {e}")
            return -1
    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return (f"Doucument(s) deleted: {result.deleted_count}")
        except PyMongoError as e:
            print(f"Error deleting document(s): {e}")
            return -1